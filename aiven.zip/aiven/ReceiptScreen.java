package aiven;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Receipt Screen — shown after payment is confirmed (QR or counter).
 *
 * paymentMethod: "QR_PAY" or "COUNTER"
 *
 * Shows:
 *  - Official receipt layout (order number, date/time, items, total, payment method)
 *  - Big pickup instruction banner
 *  - "Done" button to reset kiosk to home screen
 */
public class ReceiptScreen extends JDialog {

    // ── Palette ──────────────────────────────────────────────────
    private static final Color BG_CREAM    = new Color(0xFF, 0xF8, 0xF0);
    private static final Color ORANGE      = new Color(0xE8, 0x73, 0x0A);
    private static final Color DARK        = new Color(0x1C, 0x1C, 0x1E);
    private static final Color GREEN       = new Color(0x28, 0xA7, 0x45);
    private static final Color CARD_WHITE  = Color.WHITE;
    private static final Color BORDER_SOFT = new Color(0xE5, 0xE0, 0xD8);

    private final Menu   menuOwner;
    private final String pickupMethod;
    private final String tableNumber;
    private final String paymentMethod; // "QR_PAY" or "COUNTER"

    public ReceiptScreen(Menu menuOwner,
                         String pickupMethod,
                         String tableNumber,
                         String paymentMethod) {
        // ReceiptScreen is a top-level frame since all dialogs are already disposed
    	super(menuOwner, false);
        this.menuOwner     = menuOwner;
        this.pickupMethod  = pickupMethod;
        this.tableNumber   = tableNumber;
        this.paymentMethod = paymentMethod;

        setTitle("Josie's Cafe – Receipt");
        setSize(480, 700);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG_CREAM);
        setContentPane(root);

        // ── Header ───────────────────────────────────────────────
        JPanel header = new JPanel(new GridLayout(2, 1));
        header.setBackground(paymentMethod.equals("QR_PAY") ? GREEN : ORANGE);
        header.setPreferredSize(new Dimension(480, 80));
        header.setBorder(new EmptyBorder(10, 20, 10, 20));

        String headerLine1 = paymentMethod.equals("QR_PAY")
            ? "✓  Payment Confirmed!" : "🧾  Order Confirmed!";
        JLabel lblTitle = new JLabel(headerLine1, SwingConstants.CENTER);
        lblTitle.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 22));
        lblTitle.setForeground(Color.WHITE);

        JLabel lblSub = new JLabel("Thank you for dining at Josie's Cafe!",
                                   SwingConstants.CENTER);
        lblSub.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblSub.setForeground(new Color(0xFF, 0xFF, 0xFF, 200));

        header.add(lblTitle);
        header.add(lblSub);
        root.add(header, BorderLayout.NORTH);

        // ── Scrollable receipt body ───────────────────────────────
        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(BG_CREAM);
        body.setBorder(new EmptyBorder(18, 24, 18, 24));

        // ── Pickup instruction banner ─────────────────────────────
        body.add(buildPickupBanner());
        body.add(Box.createVerticalStrut(18));

        // ── Receipt card ──────────────────────────────────────────
        body.add(buildReceiptCard());
        body.add(Box.createVerticalStrut(16));

        // ── Footer note ───────────────────────────────────────────
        JLabel footerNote = new JLabel(
            "<html><center>Prices include VAT.<br>Please keep this receipt for your records.</center></html>",
            SwingConstants.CENTER);
        footerNote.setFont(new Font("Arial", Font.ITALIC, 11));
        footerNote.setForeground(new Color(0xAA, 0xAA, 0xAA));
        footerNote.setAlignmentX(Component.CENTER_ALIGNMENT);
        body.add(footerNote);
        body.add(Box.createVerticalStrut(16));

        JScrollPane scroll = new JScrollPane(body);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.getViewport().setBackground(BG_CREAM);
        root.add(scroll, BorderLayout.CENTER);

        // ── Done button ───────────────────────────────────────────
        JButton doneBtn = new JButton("Done — Return to Home") {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(ORANGE);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
                super.paintComponent(g);
            }
        };
        doneBtn.setContentAreaFilled(false);
        doneBtn.setBorderPainted(false);
        doneBtn.setFocusPainted(false);
        doneBtn.setForeground(Color.WHITE);
        doneBtn.setFont(new Font("SansSerif", Font.BOLD, 17));
        doneBtn.setPreferredSize(new Dimension(0, 65));
        doneBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        doneBtn.addActionListener(e -> {
            menuOwner.getCartItems().clear();
            dispose();
            menuOwner.dispose();
            new OrderManagingInterface().setVisible(true);
        });
        root.add(doneBtn, BorderLayout.SOUTH);
    }

    // ── Pickup instruction banner ─────────────────────────────────
    private JPanel buildPickupBanner() {
        boolean isTable = pickupMethod.equals("TABLE");

        JPanel banner = new JPanel(new BorderLayout(0, 6)) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(isTable ? new Color(0xFF, 0xF0, 0xD4) : new Color(0xE8, 0xFF, 0xED));
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 18, 18));
                g2.setColor(isTable ? ORANGE : GREEN);
                g2.setStroke(new java.awt.BasicStroke(2f));
                g2.draw(new RoundRectangle2D.Float(1, 1, getWidth()-2, getHeight()-2, 18, 18));
                g2.dispose();
            }
        };
        banner.setOpaque(false);
        banner.setBorder(new EmptyBorder(18, 18, 18, 18));
        banner.setAlignmentX(Component.LEFT_ALIGNMENT);
        banner.setMaximumSize(new Dimension(Integer.MAX_VALUE, 140));

        String icon = isTable ? "🪑" : "🏪";
        JLabel lblIcon = new JLabel(icon, SwingConstants.CENTER);
        lblIcon.setFont(new Font("SansSerif", Font.PLAIN, 36));
        lblIcon.setPreferredSize(new Dimension(55, 55));
        banner.add(lblIcon, BorderLayout.WEST);

        JPanel textSide = new JPanel(new GridLayout(2, 1, 0, 4));
        textSide.setOpaque(false);

        String mainMsg = isTable
            ? "Please sit at your table and wait."
            : "Please proceed to the counter to collect your order.";
        JLabel lblMain = new JLabel(
            "<html><body style='width:300px'><b>" + mainMsg + "</b></body></html>");
        lblMain.setFont(new Font("Georgia", Font.BOLD, 14));
        lblMain.setForeground(isTable ? ORANGE : GREEN);

        String subMsg = isTable
            ? "Our staff will bring your food to Table " + tableNumber + " shortly!"
            : (paymentMethod.equals("COUNTER")
                ? "Kindly pay at the counter and show this receipt."
                : "Your QR payment is confirmed. Show this receipt to our staff.");
        JLabel lblSub = new JLabel(
            "<html><body style='width:300px'>" + subMsg + "</body></html>");
        lblSub.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblSub.setForeground(DARK);

        textSide.add(lblMain);
        textSide.add(lblSub);
        banner.add(textSide, BorderLayout.CENTER);

        return banner;
    }

    // ── Receipt card ──────────────────────────────────────────────
    private JPanel buildReceiptCard() {
        JPanel card = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_WHITE);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 16, 16));
                g2.setColor(BORDER_SOFT);
                g2.setStroke(new java.awt.BasicStroke(1f));
                g2.draw(new RoundRectangle2D.Float(1, 1, getWidth()-2, getHeight()-2, 16, 16));
                g2.dispose();
            }
        };
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setOpaque(false);
        card.setBorder(new EmptyBorder(18, 20, 18, 20));
        card.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Cafe name
        JLabel lblCafe = new JLabel("JOSIE'S CAFE", SwingConstants.CENTER);
        lblCafe.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 18));
        lblCafe.setForeground(ORANGE);
        lblCafe.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblCafe);

        JLabel lblAddress = new JLabel("Official Receipt", SwingConstants.CENTER);
        lblAddress.setFont(new Font("SansSerif", Font.PLAIN, 11));
        lblAddress.setForeground(new Color(0xAA, 0xAA, 0xAA));
        lblAddress.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(lblAddress);
        card.add(Box.createVerticalStrut(10));

        // Order # and datetime
        String orderNum = String.format("%05d", (int)(Math.random() * 99999) + 1);
        String dateTime = LocalDateTime.now()
            .format(DateTimeFormatter.ofPattern("MMM dd, yyyy  hh:mm a"));

        card.add(makeReceiptRow("Order #:", orderNum, false));
        card.add(Box.createVerticalStrut(3));
        card.add(makeReceiptRow("Date/Time:", dateTime, false));
        card.add(Box.createVerticalStrut(3));

        String payLabel = paymentMethod.equals("QR_PAY") ? "QR / e-Wallet" : "Pay at Counter";
        card.add(makeReceiptRow("Payment:", payLabel, false));
        card.add(Box.createVerticalStrut(3));

        String pickupLabel = pickupMethod.equals("TABLE")
            ? "Table " + tableNumber : "Counter Pickup";
        card.add(makeReceiptRow("Pickup:", pickupLabel, false));

        card.add(Box.createVerticalStrut(12));
        card.add(makeDashedDivider());
        card.add(Box.createVerticalStrut(10));

        // Item header
        JLabel lblItemsHead = new JLabel("ITEMS ORDERED");
        lblItemsHead.setFont(new Font("Georgia", Font.BOLD, 12));
        lblItemsHead.setForeground(DARK);
        lblItemsHead.setAlignmentX(Component.LEFT_ALIGNMENT);
        card.add(lblItemsHead);
        card.add(Box.createVerticalStrut(8));

        // Items
        List<CartItem> items = menuOwner.getCartItems();
        double total = 0;
        for (CartItem item : items) {
            total += item.price;
            card.add(buildReceiptItem(item));
            card.add(Box.createVerticalStrut(6));
        }

        card.add(Box.createVerticalStrut(6));
        card.add(makeDashedDivider());
        card.add(Box.createVerticalStrut(10));

        // Total
        card.add(makeReceiptRow("TOTAL", String.format("₱%.2f", total), true));

        if (paymentMethod.equals("COUNTER")) {
            card.add(Box.createVerticalStrut(6));
            JLabel lblPay = new JLabel(
                "<html><i>Please pay ₱" + String.format("%.2f", total)
                + " at the counter.</i></html>", SwingConstants.CENTER);
            lblPay.setFont(new Font("SansSerif", Font.ITALIC, 11));
            lblPay.setForeground(ORANGE);
            lblPay.setAlignmentX(Component.CENTER_ALIGNMENT);
            card.add(lblPay);
        }

        card.add(Box.createVerticalStrut(12));
        card.add(makeDashedDivider());
        card.add(Box.createVerticalStrut(8));

        JLabel thankyou = new JLabel("Thank you! Come again! 😊", SwingConstants.CENTER);
        thankyou.setFont(new Font("Georgia", Font.ITALIC, 13));
        thankyou.setForeground(ORANGE);
        thankyou.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(thankyou);

        return card;
    }

    // ── Receipt item row ──────────────────────────────────────────
    private JPanel buildReceiptItem(CartItem item) {
        JPanel row = new JPanel(new BorderLayout(8, 0));
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, Integer.MAX_VALUE));
        row.setAlignmentX(Component.LEFT_ALIGNMENT);

        String desc = item.description;
        String displayHtml;
        if (desc.contains("(") && desc.contains(")")) {
            int paren = desc.indexOf("(");
            String main   = desc.substring(0, paren).trim();
            String detail = desc.substring(paren);
            displayHtml = "<html><body style='width:270px'><b>" + main + "</b><br>"
                + "<span style='color:#888888;font-size:10px'>" + detail + "</span></body></html>";
        } else {
            displayHtml = "<html><body style='width:270px'>" + desc + "</body></html>";
        }

        JLabel lblDesc = new JLabel(displayHtml);
        lblDesc.setFont(new Font("SansSerif", Font.PLAIN, 12));

        JLabel lblPrice = new JLabel(String.format("₱%.2f", item.price));
        lblPrice.setFont(new Font("SansSerif", Font.BOLD, 12));
        lblPrice.setForeground(ORANGE);
        lblPrice.setHorizontalAlignment(SwingConstants.RIGHT);
        lblPrice.setVerticalAlignment(SwingConstants.TOP);

        row.add(lblDesc,  BorderLayout.CENTER);
        row.add(lblPrice, BorderLayout.EAST);
        return row;
    }

    // ── Label: value row ─────────────────────────────────────────
    private JPanel makeReceiptRow(String label, String value, boolean bold) {
        JPanel row = new JPanel(new BorderLayout());
        row.setOpaque(false);
        row.setMaximumSize(new Dimension(Integer.MAX_VALUE, 26));
        row.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font("SansSerif", bold ? Font.BOLD : Font.PLAIN, bold ? 15 : 12));
        lbl.setForeground(bold ? DARK : new Color(0x66, 0x66, 0x66));

        JLabel val = new JLabel(value, SwingConstants.RIGHT);
        val.setFont(new Font("SansSerif", bold ? Font.BOLD : Font.PLAIN, bold ? 16 : 12));
        val.setForeground(bold ? ORANGE : DARK);

        row.add(lbl, BorderLayout.WEST);
        row.add(val, BorderLayout.EAST);
        return row;
    }

    // ── Dashed divider ────────────────────────────────────────────
    private JComponent makeDashedDivider() {
        JComponent dash = new JComponent() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(BORDER_SOFT);
                float[] arr = {4, 4};
                g2.setStroke(new java.awt.BasicStroke(1f, java.awt.BasicStroke.CAP_BUTT,
                    java.awt.BasicStroke.JOIN_MITER, 1f, arr, 0f));
                g2.drawLine(0, 0, getWidth(), 0);
                g2.dispose();
            }
        };
        dash.setMaximumSize(new Dimension(Integer.MAX_VALUE, 2));
        dash.setPreferredSize(new Dimension(0, 2));
        dash.setAlignmentX(Component.LEFT_ALIGNMENT);
        return dash;
    }
}