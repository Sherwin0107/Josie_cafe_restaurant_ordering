package aiven;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import javax.swing.border.EmptyBorder;

/**
 * Modal dialog shown after the customer taps "Checkout".
 * Asks: pick up at the counter, or have it served at your table?
 *
 * Result values:
 *   "COUNTER" – go straight to PaymentMethodScreen
 *   "TABLE"   – open TableNumberDialog first, then PaymentMethodScreen
 *   null      – dialog was closed without choosing
 */
public class PickupMethodDialog extends JDialog {

    // ── Palette ──────────────────────────────────────────────────
    private static final Color BG_CREAM    = new Color(0xFF, 0xF8, 0xF0);
    private static final Color ORANGE      = new Color(0xE8, 0x73, 0x0A);
    private static final Color ORANGE_DARK = new Color(0xC5, 0x60, 0x00);
    private static final Color DARK        = new Color(0x1C, 0x1C, 0x1E);
    private static final Color DARK_HOVER  = new Color(0x3A, 0x3A, 0x3C);
    private static final Color WHITE       = Color.WHITE;

    private String result = null;

    public PickupMethodDialog(JDialog owner) {
        super(owner, "How would you like to receive your order?", true);
        setSize(460, 380);
        setLocationRelativeTo(owner);
        setResizable(false);

        JPanel content = new JPanel(null);
        content.setBackground(BG_CREAM);
        setContentPane(content);

        // ── Orange top stripe ─────────────────────────────────────
        JPanel topBar = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                g.setColor(ORANGE);
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        topBar.setOpaque(false);
        topBar.setBounds(0, 0, 460, 6);
        content.add(topBar);

        // ── Title ─────────────────────────────────────────────────
        JLabel lblTitle = new JLabel("Where will you receive your order?", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Georgia", Font.BOLD, 18));
        lblTitle.setForeground(DARK);
        lblTitle.setBounds(0, 28, 460, 30);
        content.add(lblTitle);

        JLabel lblSub = new JLabel("Please select your preferred pickup method", SwingConstants.CENTER);
        lblSub.setFont(new Font("Arial", Font.ITALIC, 12));
        lblSub.setForeground(new Color(0xAA, 0xAA, 0xAA));
        lblSub.setBounds(0, 62, 460, 22);
        content.add(lblSub);

        JSeparator sep = new JSeparator();
        sep.setBounds(40, 92, 380, 2);
        sep.setForeground(new Color(0xE0, 0xD5, 0xC5));
        content.add(sep);

        // ── Counter button ────────────────────────────────────────
        JButton btnCounter = makeChoiceButton(
            "<html><center>"
            + "<span style='font-size:30px'>🏪</span><br><br>"
            + "<b style='font-size:14px'>Pick Up at Counter</b><br>"
            + "<span style='font-size:10px; color:#dddddd'>Collect your order yourself</span>"
            + "</center></html>",
            DARK, DARK_HOVER
        );
        btnCounter.setBounds(35, 112, 175, 185);
        content.add(btnCounter);
        btnCounter.addActionListener(e -> {
            result = "COUNTER";
            dispose();
        });

        // ── Table button ──────────────────────────────────────────
        JButton btnTable = makeChoiceButton(
            "<html><center>"
            + "<span style='font-size:30px'>🪑</span><br><br>"
            + "<b style='font-size:14px'>Serve at My Table</b><br>"
            + "<span style='font-size:10px; color:#ffe0c0'>We'll bring it to you</span>"
            + "</center></html>",
            ORANGE, ORANGE_DARK
        );
        btnTable.setBounds(250, 112, 175, 185);
        content.add(btnTable);
        btnTable.addActionListener(e -> {
            result = "TABLE";
            dispose();
        });

        // ── Footer hint ───────────────────────────────────────────
        JLabel lblHint = new JLabel("Tent numbers are found on your table", SwingConstants.CENTER);
        lblHint.setFont(new Font("Arial", Font.ITALIC, 11));
        lblHint.setForeground(new Color(0xAA, 0xAA, 0xAA));
        lblHint.setBounds(0, 310, 460, 20);
        content.add(lblHint);
    }

    /** Shows the dialog and returns "COUNTER", "TABLE", or null. */
    public String getResult() {
        setVisible(true); // blocks until disposed
        return result;
    }

    // ── Helper: rounded choice button ─────────────────────────────
    private JButton makeChoiceButton(String html, Color base, Color hover) {
        JButton btn = new JButton(html) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? hover : base);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 28, 28);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setForeground(WHITE);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.repaint(); }
            public void mouseExited(MouseEvent e)  { btn.repaint(); }
        });
        return btn;
    }
}