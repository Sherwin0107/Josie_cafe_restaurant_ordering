package aiven;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import javax.swing.border.EmptyBorder;

/**
 * Meal customization screen — shown as a modal JDialog.
 *
 * Two usage modes:
 *   1. From Menu (new order):
 *        new MealCustomizer(menuOwner, itemName, basePrice, null).setVisible(true);
 *
 *   2. From CheckoutScreen (edit existing cart entry):
 *        new MealCustomizer(menuOwner, item, cartIndex, checkoutScreen).setVisible(true);
 *      → on finish, replaces cart entry and reopens CheckoutScreen instead of Menu.
 */
public class MealCustomizer extends JDialog {

    // ── Palette ──────────────────────────────────────────────────
    private static final Color BG_CREAM     = new Color(0xFF, 0xF8, 0xF0);
    private static final Color ORANGE       = new Color(0xE8, 0x73, 0x0A);
    private static final Color ORANGE_DARK  = new Color(0xC5, 0x60, 0x00);
    private static final Color DARK_SIDEBAR = new Color(0x1C, 0x1C, 0x1E);
    private static final Color CARD_WHITE   = Color.WHITE;
    private static final Color BORDER_SOFT  = new Color(0xE5, 0xE0, 0xD8);
    private static final Color SELECTED_BG  = new Color(0xFF, 0xEC, 0xD5);
    private static final Color SELECTED_BD  = new Color(0xE8, 0x73, 0x0A);

    // ── Add-on data ───────────────────────────────────────────────
    private static final String[][] SIDES_CHICKEN = {
        {"Garden Salad", "+20"}, {"Coleslaw",        "+20"},
        {"Corn on the Cob", "+25"}, {"Mashed Potato", "+30"},
        {"Steamed Veggies", "+20"}, {"Mac & Cheese",  "+35"}
    };
    private static final String[][] SIDES_BURGER = {
        {"French Fries", "+25"}, {"Onion Rings",  "+30"},
        {"Coleslaw",     "+20"}, {"Garden Salad", "+20"},
        {"Hash Browns",  "+25"}, {"Potato Wedges","+30"}
    };
    private static final String[][] SIDES_GENERIC = {
        {"French Fries", "+25"}, {"Garden Salad",  "+20"},
        {"Coleslaw",     "+20"}, {"Mashed Potato", "+30"},
        {"Steamed Veggies", "+20"}, {"Onion Rings", "+30"}
    };
    private static final String[][] BEVERAGES = {
        {"Coke Regular", "+39"}, {"Coke Large",     "+55"},
        {"Iced Tea",     "+45"}, {"Mango Shake",    "+79"},
        {"Lemonade",     "+59"}, {"Mineral Water",  "+29"},
        {"Hot Coffee",   "+69"}, {"Iced Coffee",    "+85"}
    };
    private static final String[][] DESSERTS = {
        {"Halo-Halo",    "+55"}, {"Leche Flan",     "+45"},
        {"Buko Pandan",  "+40"}, {"Ice Cream Cup",  "+35"},
        {"Banana Split", "+65"}, {"Skip Dessert",   "+0" }
    };

    private static final String[] STEP_LABELS    = {"🥗 Sides", "🥤 Beverage", "🍮 Dessert"};
    private static final String[] STEP_SUBTITLES = {
        "Choose a side dish for your meal",
        "Choose a beverage to go with it",
        "Choose a dessert  (optional)"
    };

    // ── State ─────────────────────────────────────────────────────
    private final Menu           menuOwner;
    private final CheckoutScreen checkoutOwner;   // null when coming from Menu
    private final int            editIndex;       // -1 = new item

    private final String baseItemName;
    private final double baseItemPrice;

    private int    currentStep     = 0;
    private String selectedSide;
    private String selectedDrink;
    private String selectedDessert;

    private final JButton[] selectedCards = new JButton[3];

    private JPanel  itemPanel;
    private JLabel  lblStepTitle;
    private JLabel  lblStepSub;
    private JButton addToCartBtn;
    private JButton[] sidebarBtns;

    // ── Constructor: new order from Menu ──────────────────────────
    public MealCustomizer(Menu menuOwner, String itemName, double basePrice,
                          CheckoutScreen unused) {
        super(menuOwner, "Josie's Cafe – Customize Your Meal", true);
        this.menuOwner     = menuOwner;
        this.checkoutOwner = null;
        this.editIndex     = -1;
        this.baseItemName  = itemName;
        this.baseItemPrice = basePrice;
        buildUI();
    }

    // ── Constructor: edit existing cart item from CheckoutScreen ──
    public MealCustomizer(Menu menuOwner, CartItem existing, int cartIndex,
                          CheckoutScreen checkoutOwner) {
        super(menuOwner, "Josie's Cafe – Edit Your Meal", true);
        this.menuOwner      = menuOwner;
        this.checkoutOwner  = checkoutOwner;
        this.editIndex      = cartIndex;
        this.baseItemName   = existing.baseItemName;
        this.baseItemPrice  = existing.baseItemPrice;
        // pre-fill selections
        this.selectedSide    = existing.selectedSide;
        this.selectedDrink   = existing.selectedDrink;
        this.selectedDessert = existing.selectedDessert;
        buildUI();
    }

    // ── UI construction ───────────────────────────────────────────
    private void buildUI() {
        setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { dispose(); }
        });
        setSize(520, 680);
        setLocationRelativeTo(menuOwner);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG_CREAM);
        setContentPane(root);

        // Header
        JPanel header = new JPanel(new GridLayout(2, 1, 0, 0));
        header.setBackground(ORANGE);
        header.setPreferredSize(new Dimension(520, 75));
        header.setBorder(new EmptyBorder(10, 10, 10, 10));

        String headerTitle = (editIndex >= 0) ? "Edit Your Meal" : "Customize Your Meal";
        JLabel lblTitle = new JLabel(headerTitle, SwingConstants.CENTER);
        lblTitle.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 20));
        lblTitle.setForeground(Color.WHITE);

        JLabel lblBase = new JLabel(
            "Base: " + baseItemName + "  ·  ₱" + String.format("%.2f", baseItemPrice),
            SwingConstants.CENTER);
        lblBase.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblBase.setForeground(new Color(0xFF, 0xE0, 0xC0));

        header.add(lblTitle);
        header.add(lblBase);
        root.add(header, BorderLayout.NORTH);

        // Sidebar
        JPanel sidebar = new JPanel(new GridLayout(3, 1, 0, 0));
        sidebar.setBackground(DARK_SIDEBAR);
        sidebar.setPreferredSize(new Dimension(130, 0));
        sidebarBtns = new JButton[3];
        for (int i = 0; i < 3; i++) {
            sidebarBtns[i] = createSidebarBtn(STEP_LABELS[i]);
            sidebar.add(sidebarBtns[i]);
        }
        root.add(sidebar, BorderLayout.WEST);

        // Center
        JPanel center = new JPanel(new BorderLayout());
        center.setBackground(BG_CREAM);

        JPanel stepHeader = new JPanel(new GridLayout(2, 1, 0, 2));
        stepHeader.setBackground(BG_CREAM);
        stepHeader.setBorder(new EmptyBorder(16, 20, 8, 20));
        lblStepTitle = new JLabel();
        lblStepTitle.setFont(new Font("Georgia", Font.BOLD, 16));
        lblStepTitle.setForeground(DARK_SIDEBAR);
        lblStepSub = new JLabel();
        lblStepSub.setFont(new Font("SansSerif", Font.ITALIC, 12));
        lblStepSub.setForeground(new Color(0x99, 0x99, 0x99));
        stepHeader.add(lblStepTitle);
        stepHeader.add(lblStepSub);
        center.add(stepHeader, BorderLayout.NORTH);

        itemPanel = new JPanel(new GridLayout(0, 2, 12, 12));
        itemPanel.setBackground(BG_CREAM);
        itemPanel.setBorder(new EmptyBorder(4, 16, 16, 16));

        JScrollPane scroll = new JScrollPane(itemPanel);
        scroll.setBorder(null);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        scroll.getViewport().setBackground(BG_CREAM);
        center.add(scroll, BorderLayout.CENTER);
        root.add(center, BorderLayout.CENTER);

        // Add / Save button
        addToCartBtn = new JButton() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(isEnabled() ? ORANGE : new Color(0xBB, 0xBB, 0xBB));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
                super.paintComponent(g);
            }
        };
        addToCartBtn.setContentAreaFilled(false);
        addToCartBtn.setBorderPainted(false);
        addToCartBtn.setFocusPainted(false);
        addToCartBtn.setForeground(Color.WHITE);
        addToCartBtn.setFont(new Font("SansSerif", Font.BOLD, 16));
        addToCartBtn.setPreferredSize(new Dimension(0, 65));
        addToCartBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));

        String btnLabel = (editIndex >= 0) ? "Save Changes" : "Add to Cart";
        boolean canFinish = (editIndex >= 0 && selectedDessert != null);
        addToCartBtn.setEnabled(canFinish);
        addToCartBtn.setText(btnLabel + "  ·  ₱" + String.format("%.2f", baseItemPrice));
        addToCartBtn.addActionListener(e -> finalizeMeal());
        root.add(addToCartBtn, BorderLayout.SOUTH);

        loadStep(0);

        // If editing, update button price immediately
        if (editIndex >= 0 && selectedDessert != null) {
            updateCartBtnPrice();
        }
    }

    // ── Step management ───────────────────────────────────────────
    private void loadStep(int step) {
        currentStep = step;
        lblStepTitle.setText(STEP_LABELS[step]);
        lblStepSub.setText(STEP_SUBTITLES[step]);
        highlightSidebar(step);

        itemPanel.removeAll();
        String[][] options = getOptionsForStep(step);
        String preSelected = getPreSelectedForStep(step);

        for (String[] opt : options) {
            final String label    = opt[0];
            final String addonStr = opt[1];
            JButton card = createOptionCard(label, addonStr, step);

            // Pre-select previously chosen option
            if (label.equals(preSelected)) {
                card.putClientProperty("selected", true);
                card.setName(label);
                selectedCards[step] = card;
            }

            card.addActionListener(e -> onCardSelected(card, label, addonStr, step));
            itemPanel.add(card);
        }

        // Enable finish button if on dessert step and something is selected
        if (step == 2) {
            boolean ready = selectedDessert != null;
            addToCartBtn.setEnabled(ready);
            if (ready) updateCartBtnPrice();
        } else {
            addToCartBtn.setEnabled(false);
        }
        addToCartBtn.repaint();

        itemPanel.revalidate();
        itemPanel.repaint();
    }

    private String getPreSelectedForStep(int step) {
        switch (step) {
            case 0: return selectedSide;
            case 1: return selectedDrink;
            case 2: return selectedDessert;
            default: return null;
        }
    }

    private void onCardSelected(JButton card, String label, String addonStr, int step) {
        if (selectedCards[step] != null) {
            selectedCards[step].putClientProperty("selected", false);
            selectedCards[step].repaint();
        }
        card.putClientProperty("selected", true);
        card.setName(label);
        card.repaint();
        selectedCards[step] = card;

        switch (step) {
            case 0: selectedSide    = label; autoAdvanceAfterDelay(1); break;
            case 1: selectedDrink   = label; autoAdvanceAfterDelay(2); break;
            case 2:
                selectedDessert = label;
                addToCartBtn.setEnabled(true);
                addToCartBtn.repaint();
                updateCartBtnPrice();
                break;
        }
    }

    private void autoAdvanceAfterDelay(int nextStep) {
        Timer t = new Timer(350, e -> loadStep(nextStep));
        t.setRepeats(false);
        t.start();
    }

    private void updateCartBtnPrice() {
        double running = baseItemPrice
            + parseAddon(selectedSide,    getOptionsForStep(0))
            + parseAddon(selectedDrink,   getOptionsForStep(1))
            + parseAddon(selectedDessert, getOptionsForStep(2));
        String btnLabel = (editIndex >= 0) ? "Save Changes" : "Add to Cart";
        addToCartBtn.setText(String.format(btnLabel + "  ·  ₱%.2f", running));
        addToCartBtn.repaint();
    }

    private double parseAddon(String selectedLabel, String[][] options) {
        if (selectedLabel == null) return 0;
        for (String[] o : options) {
            if (o[0].equals(selectedLabel))
                return Double.parseDouble(o[1].replace("+", ""));
        }
        return 0;
    }

    private String[][] getOptionsForStep(int step) {
        switch (step) {
            case 1: return BEVERAGES;
            case 2: return DESSERTS;
            default:
                String n = baseItemName.toLowerCase();
                if (n.contains("chicken") || n.contains("inasal")
                        || n.contains("nugget") || n.contains("wing")
                        || n.contains("strip"))  return SIDES_CHICKEN;
                if (n.contains("burger"))        return SIDES_BURGER;
                return SIDES_GENERIC;
        }
    }

    // ── Finalize ──────────────────────────────────────────────────
    private void finalizeMeal() {
        try {
            double total = baseItemPrice
                + parseAddon(selectedSide,    getOptionsForStep(0))
                + parseAddon(selectedDrink,   getOptionsForStep(1))
                + parseAddon(selectedDessert, getOptionsForStep(2));

            String summary = String.format(
                "%s Meal  (Side: %s | Drink: %s | Dessert: %s)",
                baseItemName,
                selectedSide    != null ? selectedSide    : "—",
                selectedDrink   != null ? selectedDrink   : "—",
                selectedDessert != null ? selectedDessert : "—"
            );

            CartItem newItem = new CartItem(
                summary, total,
                baseItemName, baseItemPrice,
                selectedSide, selectedDrink, selectedDessert
            );

            if (editIndex >= 0 && menuOwner != null) {
                // Editing existing — replace in cart
                menuOwner.replaceCartItem(editIndex, newItem);
                dispose();
                // Reopen checkout screen directly
                new CheckoutScreen(menuOwner).setVisible(true);
            } else {
                // New item — add to cart, return to menu
                if (menuOwner != null) menuOwner.addCartItem(newItem);
                dispose();
            }

        } catch (Exception ex) {
            ex.printStackTrace();
            dispose();
        }
    }

    // ── UI helpers ────────────────────────────────────────────────
    private JButton createOptionCard(String name, String addonStr, int step) {
        JButton btn = new JButton() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                boolean sel = Boolean.TRUE.equals(getClientProperty("selected"));
                g2.setColor(sel ? SELECTED_BG : CARD_WHITE);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 20, 20));
                g2.setColor(sel ? SELECTED_BD : BORDER_SOFT);
                g2.setStroke(new BasicStroke(sel ? 2f : 1f));
                g2.draw(new RoundRectangle2D.Float(1, 1, getWidth()-2, getHeight()-2, 20, 20));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setName(name);
        btn.setLayout(new BorderLayout());
        String priceLabel = addonStr.equals("+0")
            ? "<font color='#888888'>Free</font>"
            : "<font color='#E8730A'>" + addonStr + "</font>";
        JLabel lbl = new JLabel(
            "<html><center><b>" + name + "</b><br>" + priceLabel + "</center></html>",
            SwingConstants.CENTER);
        lbl.setFont(new Font("SansSerif", Font.PLAIN, 13));
        btn.add(lbl);
        btn.setPreferredSize(new Dimension(140, 110));
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.putClientProperty("selected", false);
        return btn;
    }

    private JButton createSidebarBtn(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("SansSerif", Font.BOLD, 12));
        btn.setForeground(new Color(200, 200, 200));
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private void highlightSidebar(int active) {
        for (int i = 0; i < sidebarBtns.length; i++) {
            boolean on = (i == active);
            sidebarBtns[i].setForeground(on ? ORANGE : new Color(200, 200, 200));
            sidebarBtns[i].setFont(new Font("SansSerif",
                on ? Font.BOLD : Font.PLAIN, on ? 13 : 12));
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() ->
            new MealCustomizer(null, "Chicken Inasal", 119.00, null).setVisible(true));
    }
}