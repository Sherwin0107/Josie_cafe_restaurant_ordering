package aiven;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Menu extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;

    // ── Palette ──────────────────────────────────────────────────
    private static final Color BG_CREAM     = new Color(0xFF, 0xF8, 0xF0);
    private static final Color ORANGE       = new Color(0xE8, 0x73, 0x0A);
    private static final Color ORANGE_DARK  = new Color(0xC5, 0x60, 0x00);
    private static final Color DARK_SIDEBAR = new Color(0x1C, 0x1C, 0x1E);
    private static final Color CARD_WHITE   = Color.WHITE;
    private static final Color BORDER_SOFT  = new Color(0xE5, 0xE0, 0xD8);

    // ── Cart state ───────────────────────────────────────────────
    private final List<CartItem> cartItems = new ArrayList<>();
    private double  cartTotal  = 0;
    private JButton checkoutBtn;
    private JPanel  itemPanel;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try { new Menu().setVisible(true); }
            catch (Exception e) { e.printStackTrace(); }
        });
    }

    public Menu() {
        setTitle("Josie's Cafe - Menu");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(520, 700);
        setLocationRelativeTo(null);

        contentPane = new JPanel(new BorderLayout());
        contentPane.setBackground(BG_CREAM);
        setContentPane(contentPane);

        // ── Header ──────────────────────────────────────────────
        JPanel headerBar = new JPanel(new BorderLayout());
        headerBar.setBackground(ORANGE);
        headerBar.setPreferredSize(new Dimension(520, 70));
        JLabel lblTitle = new JLabel("JOSIE'S CAFE  —  Menu", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 22));
        lblTitle.setForeground(Color.WHITE);
        headerBar.add(lblTitle, BorderLayout.CENTER);
        contentPane.add(headerBar, BorderLayout.NORTH);

        // ── Sidebar ──────────────────────────────────────────────
        JPanel leftPanel = new JPanel(new BorderLayout());
        leftPanel.setBackground(DARK_SIDEBAR);
        leftPanel.setPreferredSize(new Dimension(130, 0));

        JPanel catContainer = new JPanel(new GridLayout(0, 1, 0, 12));
        catContainer.setOpaque(false);
        catContainer.setBorder(new EmptyBorder(20, 10, 20, 10));

        String[] categories = {"🍗 Chicken", "🍔 Burgers", "🥤 Drinks", "🍚 Rice"};
        for (int i = 0; i < categories.length; i++) {
            final int index = i;
            JButton catBtn = createSidebarBtn(categories[i]);
            catBtn.addActionListener(e -> loadCategory(index));
            catContainer.add(catBtn);
        }
        leftPanel.add(catContainer, BorderLayout.NORTH);
        contentPane.add(leftPanel, BorderLayout.WEST);

        // ── Main Item Grid ───────────────────────────────────────
        itemPanel = new JPanel(new GridLayout(0, 2, 15, 15));
        itemPanel.setBackground(BG_CREAM);
        itemPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JScrollPane scrollPane = new JScrollPane(itemPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getViewport().setBackground(BG_CREAM);
        contentPane.add(scrollPane, BorderLayout.CENTER);

        // ── Checkout Button ──────────────────────────────────────
        checkoutBtn = createCheckoutBtn();
        checkoutBtn.setPreferredSize(new Dimension(0, 65));
        checkoutBtn.addActionListener(e -> openCheckout());
        contentPane.add(checkoutBtn, BorderLayout.SOUTH);

        loadCategory(0);
    }

    // ── Load a category's items ──────────────────────────────────
    private void loadCategory(int idx) {
        String[] categories = {"Chicken", "Burger", "Drinks", "Rice"};
        String selectedCategory = categories[idx];

        itemPanel.removeAll();

        // ← productId added to SELECT
        String sql = "SELECT productId, productName, price FROM products WHERE category = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, selectedCategory);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                int    id    = rs.getInt("productId");
                String name  = rs.getString("productName");
                String price = String.format("%.2f", rs.getDouble("price"));
                JButton card = createMenuCard(name, price);
                // ← productId passed into click handler
                card.addActionListener(e -> handleItemClick(name, price, id));
                itemPanel.add(card);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        itemPanel.revalidate();
        itemPanel.repaint();
    }

    // ← productId added as parameter
    private void handleItemClick(String name, String price, int productId) {
        MealTypeDialog dialog = new MealTypeDialog(this, name, price);
        Boolean wantsMeal = dialog.getResult();

        if (wantsMeal == null) return;

        double priceVal = Double.parseDouble(price);

        if (!wantsMeal) {
            // ← productId passed to Ala Carte CartItem
            CartItem ci = new CartItem(name + " (Ala Carte)", priceVal, productId);
            addCartItem(ci);
        } else {
            // ← productId passed to MealCustomizer
            new MealCustomizer(this, name, priceVal, productId, null).setVisible(true);
        }
    }

    /** Called by MealCustomizer to commit a finished meal item. */
    public void addCartItem(CartItem item) {
        cartItems.add(item);
        cartTotal += item.price;
        updateCheckoutBtn();
        showToast(item.description + " added!");
    }

    /** Called by CheckoutScreen after an item was edited — replaces old entry. */
    public void replaceCartItem(int index, CartItem newItem) {
        if (index >= 0 && index < cartItems.size()) {
            cartTotal -= cartItems.get(index).price;
            cartItems.set(index, newItem);
            cartTotal += newItem.price;
            updateCheckoutBtn();
        }
    }

    /** Called by CheckoutScreen to delete an item. */
    public void removeCartItem(int index) {
        if (index >= 0 && index < cartItems.size()) {
            cartTotal -= cartItems.get(index).price;
            cartItems.remove(index);
            updateCheckoutBtn();
        }
    }

    public List<CartItem> getCartItems() { return cartItems; }

    private void updateCheckoutBtn() {
        checkoutBtn.setText(cartItems.isEmpty()
            ? "Proceed to Checkout  ·  ₱0.00"
            : String.format("Proceed to Checkout  ·  ₱%.2f", cartTotal));
    }

    private void openCheckout() {
        if (cartItems.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Your cart is empty!", "Nothing to checkout",
                JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        new CheckoutScreen(this).setVisible(true);
    }

    // ── Toast notification ────────────────────────────────────────
    public void showToast(String message) {
        JWindow toast = new JWindow(this);
        JLabel lbl = new JLabel(" ✓  " + message + " ", SwingConstants.CENTER);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 13));
        lbl.setForeground(Color.WHITE);
        lbl.setOpaque(true);
        lbl.setBackground(new Color(0x1C, 0x1C, 0x1E, 220));
        lbl.setBorder(BorderFactory.createEmptyBorder(10, 16, 10, 16));
        toast.add(lbl);
        toast.pack();

        Point loc = getLocationOnScreen();
        int x = loc.x + (getWidth()  - toast.getWidth())  / 2;
        int y = loc.y + getHeight() - 140;
        toast.setLocation(x, y);
        toast.setVisible(true);

        Timer t = new Timer(2000, e -> toast.dispose());
        t.setRepeats(false);
        t.start();
    }

    // ── UI helpers ────────────────────────────────────────────────
    private JButton createSidebarBtn(String text) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("SansSerif", Font.BOLD, 12));
        btn.setForeground(new Color(200, 200, 200));
        btn.setFocusPainted(false);
        btn.setContentAreaFilled(false);
        btn.setBorder(BorderFactory.createEmptyBorder(15, 5, 15, 5));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setForeground(ORANGE); }
            public void mouseExited(MouseEvent e)  { btn.setForeground(new Color(200, 200, 200)); }
        });
        return btn;
    }

    private JButton createMenuCard(String name, String price) {
        JButton btn = new JButton() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_WHITE);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 20, 20));
                g2.setColor(BORDER_SOFT);
                g2.draw(new RoundRectangle2D.Float(0, 0, getWidth()-1, getHeight()-1, 20, 20));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setLayout(new BorderLayout());
        JLabel lbl = new JLabel(
            "<html><center><b>" + name + "</b><br>"
            + "<font color='#E8730A'>₱" + price + "</font></center></html>",
            SwingConstants.CENTER
        );
        lbl.setFont(new Font("SansSerif", Font.PLAIN, 13));
        btn.add(lbl);
        btn.setPreferredSize(new Dimension(140, 120));
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private JButton createCheckoutBtn() {
        JButton btn = new JButton("Proceed to Checkout  ·  ₱0.00");
        btn.setBackground(ORANGE);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("SansSerif", Font.BOLD, 16));
        btn.setOpaque(true);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }
}