package aiven;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;

/**
 * Modal dialog that lets the customer enter the tent/table number
 * displayed on their table. Shown only when "Serve at My Table" is chosen.
 *
 * Returns the entered table number as a String, or null if cancelled.
 */
public class TableNumberDialog extends JDialog {

    // ── Palette ──────────────────────────────────────────────────
    private static final Color BG_CREAM    = new Color(0xFF, 0xF8, 0xF0);
    private static final Color ORANGE      = new Color(0xE8, 0x73, 0x0A);
    private static final Color ORANGE_DARK = new Color(0xC5, 0x60, 0x00);
    private static final Color DARK        = new Color(0x1C, 0x1C, 0x1E);
    private static final Color CARD_WHITE  = Color.WHITE;
    private static final Color BORDER_SOFT = new Color(0xE5, 0xE0, 0xD8);

    private String result = null;

    // Number pad labels
    private static final String[] PAD_KEYS = {
        "1", "2", "3",
        "4", "5", "6",
        "7", "8", "9",
        "⌫", "0", "✓"
    };

    public TableNumberDialog(JDialog owner) {
        super(owner, "Enter Your Table Number", true);
        setSize(380, 540);
        setLocationRelativeTo(owner);
        setResizable(false);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG_CREAM);
        setContentPane(root);

        // ── Orange header ─────────────────────────────────────────
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(ORANGE);
        header.setPreferredSize(new Dimension(380, 75));
        header.setBorder(new EmptyBorder(10, 20, 10, 20));

        JLabel lblTitle = new JLabel("Enter Your Table Number", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Georgia", Font.BOLD | Font.ITALIC, 18));
        lblTitle.setForeground(Color.WHITE);

        JLabel lblSub = new JLabel("Check the tent card on your table", SwingConstants.CENTER);
        lblSub.setFont(new Font("SansSerif", Font.PLAIN, 12));
        lblSub.setForeground(new Color(0xFF, 0xE0, 0xC0));

        header.add(lblTitle, BorderLayout.CENTER);
        header.add(lblSub, BorderLayout.SOUTH);
        root.add(header, BorderLayout.NORTH);

        // ── Center: display + numpad ──────────────────────────────
        JPanel center = new JPanel(new BorderLayout(0, 0));
        center.setBackground(BG_CREAM);
        center.setBorder(new EmptyBorder(20, 24, 20, 24));
        root.add(center, BorderLayout.CENTER);

        // Display field
        final JLabel[] displayHolder = new JLabel[1];
        JPanel displayPanel = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(CARD_WHITE);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 16, 16));
                g2.setColor(BORDER_SOFT);
                g2.setStroke(new BasicStroke(1.5f));
                g2.draw(new RoundRectangle2D.Float(1, 1, getWidth()-2, getHeight()-2, 16, 16));
                g2.dispose();
            }
        };
        displayPanel.setOpaque(false);
        displayPanel.setPreferredSize(new Dimension(0, 70));
        displayPanel.setBorder(new EmptyBorder(0, 20, 0, 20));

        JLabel lblDisplay = new JLabel("—", SwingConstants.CENTER);
        lblDisplay.setFont(new Font("Georgia", Font.BOLD, 42));
        lblDisplay.setForeground(DARK);
        displayPanel.add(lblDisplay, BorderLayout.CENTER);
        displayHolder[0] = lblDisplay;
        center.add(displayPanel, BorderLayout.NORTH);

        // Instruction under display
        JLabel lblInstr = new JLabel("Type or tap your table number below", SwingConstants.CENTER);
        lblInstr.setFont(new Font("Arial", Font.ITALIC, 11));
        lblInstr.setForeground(new Color(0xAA, 0xAA, 0xAA));
        lblInstr.setBorder(new EmptyBorder(8, 0, 12, 0));
        center.add(lblInstr, BorderLayout.CENTER);

        // Number pad
        JPanel pad = new JPanel(new GridLayout(4, 3, 10, 10));
        pad.setOpaque(false);
        final StringBuilder entered = new StringBuilder();

        for (String key : PAD_KEYS) {
            JButton btn = createPadButton(key);
            btn.addActionListener(e -> {
                String k = btn.getText();
                if (k.equals("⌫")) {
                    if (entered.length() > 0)
                        entered.deleteCharAt(entered.length() - 1);
                } else if (k.equals("✓")) {
                    // Confirm
                    String val = entered.toString().trim();
                    if (val.isEmpty()) {
                        JOptionPane.showMessageDialog(TableNumberDialog.this,
                            "Please enter your table number first.",
                            "No Table Number", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
                    result = val;
                    dispose();
                    return;
                } else {
                    // Only allow up to 3 digits
                    if (entered.length() < 3) entered.append(k);
                }
                lblDisplay.setText(entered.length() == 0 ? "—" : entered.toString());
            });
            pad.add(btn);
        }

        center.add(pad, BorderLayout.SOUTH);
    }

    /** Shows the dialog and returns the entered table number, or null. */
    public String getResult() {
        setVisible(true);
        return result;
    }

    // ── Number pad button ─────────────────────────────────────────
    private JButton createPadButton(String label) {
        boolean isConfirm = label.equals("✓");
        boolean isDelete  = label.equals("⌫");

        Color base  = isConfirm ? new Color(0xE8, 0x73, 0x0A)
                    : isDelete  ? new Color(0x55, 0x55, 0x58)
                    :             new Color(0x2C, 0x2C, 0x2E);
        Color hover = isConfirm ? new Color(0xC5, 0x60, 0x00)
                    : isDelete  ? new Color(0x3A, 0x3A, 0x3C)
                    :             new Color(0x3A, 0x3A, 0x3C);

        JButton btn = new JButton(label) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? hover : base);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 14, 14);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font(isConfirm || isDelete ? "SansSerif" : "Georgia",
                             Font.BOLD,
                             isConfirm || isDelete ? 18 : 22));
        btn.setPreferredSize(new Dimension(80, 58));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.repaint(); }
            public void mouseExited(MouseEvent e)  { btn.repaint(); }
        });
        return btn;
    }
}